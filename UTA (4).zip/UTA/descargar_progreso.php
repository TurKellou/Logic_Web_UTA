<?php
session_start();
require_once 'includes/conexion.php';

// Verificar que el usuario haya iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: modulos/usuarios/login.php");
    exit();
}

$usuario_id = $_SESSION['user_id'];
$nombre_usuario = preg_replace('/[^a-zA-Z0-9_]/', '_', $_SESSION['user_name']);

// Configurar los encabezados HTTP para forzar la descarga como CSV (Excel)
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=Reporte_Progreso_' . $nombre_usuario . '_' . date('Ymd_His') . '.csv');

// Abrir la salida de PHP
$salida = fopen('php://output', 'w');

// Imprimir el BOM para que Excel lea correctamente las tildes y eñes
fprintf($salida, chr(0xEF).chr(0xBB).chr(0xBF));

// Escribir los encabezados con las columnas reales, forzando el separador ';'
fputcsv($salida, ['ID Intento', 'Tema', 'Ejercicio', 'Respuesta Enviada', 'Resultado', 'Fecha'], ';');

// Consultar el historial usando exactamente los nombres de tu tabla
$sql = "SELECT i.IdIntento, t.NombreTema, e.Titulo, i.RespuestaUsuario, i.Resultado, i.Fecha 
        FROM intento i
        JOIN ejercicio e ON i.IdEjercicio = e.IdEjercicio
        JOIN tema t ON e.IdTema = t.IdTema
        WHERE i.IdUsuario = ?
        ORDER BY i.Fecha DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$usuario_id]);

// Recorrer los resultados y agregarlos al Excel
while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Convertir el número del resultado en texto legible para el profesor
    $estado = ($fila['Resultado'] == 1) ? 'Correcto' : 'Incorrecto';
    
    // Forzamos el separador ';' en cada fila de datos
    fputcsv($salida, [
        $fila['IdIntento'],
        $fila['NombreTema'],
        $fila['Titulo'],
        $fila['RespuestaUsuario'],
        $estado,
        $fila['Fecha']
    ], ';');
}

fclose($salida);
exit();
?>