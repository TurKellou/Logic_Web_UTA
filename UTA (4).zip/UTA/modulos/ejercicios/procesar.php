<?php
session_start();
require_once '../../includes/conexion.php';

// Forzar salida en JSON para que el SweetAlert no falle
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_ejercicio = $_POST['id_ejercicio'] ?? null;
    $respuesta_usuario = $_POST['respuesta_usuario'] ?? null;
    $usuario_id = $_SESSION['user_id'] ?? null;

    if (!$id_ejercicio || $respuesta_usuario === null) {
        echo json_encode(['status' => 'error', 'message' => 'Faltan datos.', 'recomendacion' => 'Por favor, llena todos los campos.']);
        exit;
    }

    $es_correcto = false;
    $mensaje = '';
    $recomendacion = '';

    // EVALUACIÓN DE LÓGICA SEGÚN EL EJERCICIO
    if ($id_ejercicio == 1) { // Promedios
        $n1 = (float)$_POST['n1'];
        $n2 = (float)$_POST['n2'];
        $n3 = (float)$_POST['n3'];
        $promedio = ($n1 + $n2 + $n3) / 3;
        $estado_real = ($promedio >= 7) ? "Aprobado" : "Reprobado";

        if (strcasecmp(trim($respuesta_usuario), $estado_real) === 0) {
            $es_correcto = true;
            $mensaje = "El promedio es " . number_format($promedio, 2) . " y el estado es " . $estado_real . ".";
            $recomendacion = "Comprendes muy bien las estructuras condicionales.";
        } else {
            $mensaje = "El resultado esperado era '" . $estado_real . "' (Promedio: " . number_format($promedio, 2) . ").";
            $recomendacion = "Revisa tu condición. Recuerda que se aprueba con 7 o más.";
        }

    } elseif ($id_ejercicio == 2) { // Sueldos
        $horas = (float)$_POST['horas'];
        $tarifa = (float)$_POST['tarifa'];
        $sueldo_real = $horas * $tarifa;

        if ((float)$respuesta_usuario === $sueldo_real) {
            $es_correcto = true;
            $mensaje = "El sueldo es $" . number_format($sueldo_real, 2) . ".";
            $recomendacion = "Dominas las operaciones aritméticas básicas.";
        } else {
            $mensaje = "El sueldo real calculado sería $" . number_format($sueldo_real, 2) . ".";
            $recomendacion = "Verifica tu multiplicación de horas por tarifa.";
        }

    } elseif ($id_ejercicio == 3) { // Arreglos
        $v1 = (float)$_POST['v1'];
        $v2 = (float)$_POST['v2'];
        $v3 = (float)$_POST['v3'];
        $suma_real = $v1 + $v2 + $v3;

        if ((float)$respuesta_usuario === $suma_real) {
            $es_correcto = true;
            $mensaje = "La suma del arreglo es " . $suma_real . ".";
            $recomendacion = "Entiendes perfectamente cómo un bucle acumula valores de un arreglo.";
        } else {
            $mensaje = "La suma real de los elementos insertados es " . $suma_real . ".";
            $recomendacion = "Recuerda que un bucle para sumar debe acumular todos los elementos insertados.";
        }

    } elseif ($id_ejercicio == 4) { // Listas (LinkedList)
        $e1 = (float)$_POST['e1'];
        $e2 = (float)$_POST['e2'];
        // En C++ push_back inserta al final. El último agregado es el e2.
        $ultimo_real = $e2;

        if ((float)$respuesta_usuario === $ultimo_real) {
            $es_correcto = true;
            $mensaje = "La función push_back() coloca el " . $e2 . " al final de la lista.";
            $recomendacion = "Comprendes la naturaleza FIFO y el comportamiento dinámico de las listas enlazadas.";
        } else {
            $mensaje = "El último elemento sería " . $e2 . ".";
            $recomendacion = "La función push_back() inserta elementos al FINAL. El último ingresado ocupa la última posición.";
        }
        
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Ejercicio no programado aún.', 'recomendacion' => 'Contacta al administrador.']);
        exit;
    }

    // REGISTRAR INTENTO EN LA BASE DE DATOS (Para el Excel)
    if ($usuario_id) {
        try {
            $resultado_int = $es_correcto ? 1 : 0;
            // Etiquetamos la respuesta con un prefijo para que el profesor sepa que fue una "Práctica"
            $respuesta_excel = "Dato: " . $respuesta_usuario; 
            
            $stmt = $pdo->prepare("INSERT INTO intento (IdUsuario, IdEjercicio, RespuestaUsuario, Resultado) VALUES (?, ?, ?, ?)");
            $stmt->execute([$usuario_id, $id_ejercicio, $respuesta_excel, $resultado_int]);
        } catch (PDOException $e) {
            // Error silencioso para no dañar la alerta visual
        }
    }

    // RESPUESTA AL FRONTEND
    if ($es_correcto) {
        echo json_encode(['status' => 'success', 'message' => $mensaje, 'recomendacion' => $recomendacion]);
    } else {
        echo json_encode(['status' => 'error', 'message' => $mensaje, 'recomendacion' => $recomendacion]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.', 'recomendacion' => 'Envía los datos por POST.']);
}
?>