<?php
session_start();
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. RADAR: Atrapamos los datos sin importar cómo los envíe el JavaScript original
    $json_data = json_decode(file_get_contents('php://input'), true) ?: [];
    
    // Buscamos el ID por todos los nombres posibles (POST, JSON o URL)
    $id_ejercicio = $_POST['id_ejercicio'] ?? $_POST['id'] ?? $_GET['id'] ?? $json_data['id_ejercicio'] ?? $json_data['id'] ?? null;
    
    // Buscamos el arreglo de las líneas de código por todos los nombres posibles
$orden_usuario = $_POST['orden_usuario'] ?? $_POST['respuesta_usuario'] ?? $_POST['orden'] ?? $_POST['lineas'] ?? $_POST['datos'] ?? $json_data['respuesta_usuario'] ?? $json_data['orden'] ?? $json_data['lineas'] ?? $json_data['datos'] ?? null;    
    $usuario_id = $_SESSION['user_id'] ?? null;

    // Si aún así no llega nada, el sistema nos "chismeará" exactamente qué está recibiendo
    if (!$id_ejercicio || !$orden_usuario || !$usuario_id) {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Faltan datos.', 
            'recomendacion' => 'DEBUG -> POST llegó como: ' . json_encode($_POST)
        ]);
        exit();
    }

    // 2. Unimos el arreglo del JS con el separador '|' para que coincida exactamente con la BD
    $respuesta_usuario_str = is_array($orden_usuario) ? implode('|', $orden_usuario) : $orden_usuario;
    $respuesta_usuario_str = trim($respuesta_usuario_str);

    try {
        $stmt = $pdo->prepare("SELECT LineasPseudocodigo FROM ejercicio WHERE IdEjercicio = ?");
        $stmt->execute([$id_ejercicio]);
        $ejercicio = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($ejercicio) {
            $respuesta_correcta = trim($ejercicio['LineasPseudocodigo']);

            $es_correcto = ($respuesta_usuario_str === $respuesta_correcta);
            $resultado_intento = $es_correcto ? 1 : 0;

            // Guardamos el intento en el historial
            $insert = $pdo->prepare("INSERT INTO intento (IdUsuario, IdEjercicio, RespuestaUsuario, Resultado) VALUES (?, ?, ?, ?)");
            $insert->execute([$usuario_id, $id_ejercicio, $respuesta_usuario_str, $resultado_intento]);

            // Devolvemos la respuesta visual
            if ($es_correcto) {
                echo json_encode([
                    'status' => 'success',
                    'message' => '¡Excelente! Lógica correcta.',
                    'recomendacion' => 'Has estructurado el código perfectamente. ¡Sigue así!'
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Secuencia Incorrecta',
                    // Si te equivocas, esto te mostrará qué fue lo que armaste para que compares
                    'recomendacion' => 'El código que enviaste fue: ' . str_replace('|', ' -> ', $respuesta_usuario_str)
                ]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error 404', 'recomendacion' => 'El ejercicio no existe en la base de datos.']);
        }
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Error BD', 'recomendacion' => $e->getMessage()]);
    }
}
?>