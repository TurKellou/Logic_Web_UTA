<?php
require_once '../../includes/conexion.php';
session_start();

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $mensaje = "<div class='alert alert-danger'>Las contraseñas no coinciden.</div>";
    } else {
        // Verificar si el correo ya existe
        $check = $pdo->prepare("SELECT * FROM Usuario WHERE Correo = ?");
        $check->execute([$correo]);
        
        if ($check->rowCount() > 0) {
            $mensaje = "<div class='alert alert-warning'>El correo ya está registrado.</div>";
        } else {
            // Encriptar contraseña y guardar
            $pass_hash = password_hash($password, PASSWORD_BCRYPT);
            $sql = "INSERT INTO Usuario (Nombre, Correo, Contrasena, Rol) VALUES (?, ?, ?, 'Estudiante')";
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute([$nombre, $correo, $pass_hash])) {
                header("Location: login.php?registro=exito");
                exit();
            } else {
                $mensaje = "<div class='alert alert-danger'>Error al registrar el usuario.</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro | LogicWeb UTA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Crear Cuenta</h3>
                    <?php echo $mensaje; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nombre Completo</label>
                            <input type="text" name="nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" name="correo" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contraseña</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirmar Contraseña</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Registrarse</button>
                    </form>
                    <p class="text-center mt-3">¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>