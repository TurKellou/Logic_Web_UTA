<?php
require_once '../../includes/conexion.php';
session_start();

$mensaje = "";

if (isset($_GET['registro']) && $_GET['registro'] == 'exito') {
    $mensaje = "<div class='alert alert-success'>Registro exitoso. ¡Inicia sesión!</div>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM Usuario WHERE Correo = ?");
    $stmt->execute([$correo]);
    $user = $stmt->fetch();

    // CORRECCIÓN: Comparación directa porque las contraseñas están en texto plano en la BD
    if ($user && $password === $user['Contrasena']) {
        // Crear variables de sesión
        $_SESSION['user_id'] = $user['IdUsuario'];
        $_SESSION['user_name'] = $user['Nombre'];
        $_SESSION['user_rol'] = $user['Rol'];
        
        header("Location: ../../index.php");
        exit();
    } else {
        $mensaje = "<div class='alert alert-danger'>Correo o contraseña incorrectos.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login | LogicWeb UTA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Iniciar Sesión</h3>
                    <?php echo $mensaje; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" name="correo" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contraseña</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Entrar</button>
                    </form>
                    <p class="text-center mt-3">¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>